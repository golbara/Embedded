**Compatible with Arduino Due only**

The Audio library enables an Arduino Due board to play back .wav files from a storage device like an SD card.

The Due uses the DAC0 and DAC1 pins to play sounds.

To use this library:

```
#include <Audio.h>
```

> The Audio library and associated functions are experimental. While it is not likely the API will change in future releases, it is still under development.